<?php
class Api
{
    public $consumerkey = "ck_bd40b4ca7f52ba0fe3ec396d7a6d35208b3a639b";
    public $consumersecret = "cs_ed3329d60cc43784de1872e8a42678018cd8cc78";
}
