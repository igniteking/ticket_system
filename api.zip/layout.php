<?php include('./connections/connection.php'); ?>
<?php include('./connections/global.php'); ?>
<?php include('./connections/functions.php'); ?>
<?php include('./components/header.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_navbar.html -->
        <?php include('./components/navbar.php'); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <?php include('./components/sidebar.php'); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="home-tab">
                                <div class="tab-content tab-content-basic">
                                    <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="statistics-details d-flex align-items-center justify-content-between">
                                                    <div>
                                                        <p class="statistics-title">Total Admin</p>
                                                        <center>
                                                            <h3 class="rate-percentage"><?php echo mysqli_num_rows((mysqli_query($conn, "SELECT * FROM `user_data` WHERE `user_type` = 'admin'"))); ?></h3>
                                                        </center>
                                                    </div>
                                                    <div>
                                                        <p class="statistics-title">Total Tickets</p>
                                                        <center>
                                                            <h3 class="rate-percentage">
                                                                <?php
                                                                $z = 0;
                                                                $get_all_tickets = mysqli_query($conn, "SELECT * FROM ticket");
                                                                while ($row = mysqli_fetch_array($get_all_tickets)) {
                                                                    $ticket_quantity = ($row["ticket_quantity"]);
                                                                    $ticket_name = ($row["ticket_name"]);
                                                                    $z += (array_sum($ticket_quantity = explode(',', $ticket_quantity)));
                                                                }
                                                                echo $z;
                                                                ?></h3>
                                                        </center>
                                                    </div>
                                                    <div>
                                                        <p class="statistics-title">Total Number Of Users</p>
                                                        <center>
                                                            <h3 class="rate-percentage"><?php echo mysqli_num_rows((mysqli_query($conn, "SELECT * FROM `client`"))); ?></h3>
                                                        </center>
                                                    </div>
                                                    <div>
                                                        <p class="statistics-title">Yearly Membership – Couple</p>
                                                        <center>
                                                            <h3 class="rate-percentage"><?php echo $AMUSEMENT = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%Yearly Membership – Couple%'")); ?></h3>
                                                        </center>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="statistics-details d-flex align-items-center justify-content-between">
                                                    <div class="d-none d-md-block">
                                                        <p class="statistics-title">AMUSEMENT PARK</p>
                                                        <center>
                                                            <h3 class="rate-percentage">
                                                                <?php
                                                                echo $AMUSEMENT = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%AMUSEMENT%'"));
                                                                ?>
                                                            </h3>
                                                        </center>
                                                    </div>
                                                    <div class="d-none d-md-block">
                                                        <p class="statistics-title">WUNDER WATER</p>
                                                        <center>
                                                            <h3 class="rate-percentage">
                                                                <?php
                                                                echo $WUNDER = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%WUNDER%'"));
                                                                ?>
                                                            </h3>
                                                        </center>
                                                    </div>
                                                    <div class="d-none d-md-block">
                                                        <p class="statistics-title">AMUSEMENT PARK + WUNDER WATER</p>
                                                        <center>
                                                            <h3 class="rate-percentage">
                                                                <?php
                                                                echo $get_all_tickets_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%COMBO%'"));
                                                                ?>
                                                            </h3>
                                                        </center>
                                                    </div>
                                                    <div class="d-none d-md-block">
                                                        <p class="statistics-title">Yearly Membership – Family</p>
                                                        <center>
                                                            <h3 class="rate-percentage"><?php
                                                                                        echo $get_all_tickets_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%Yearly Membership – Family%'"));
                                                                                        ?></h3>
                                                        </center>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-8 d-flex flex-column">
                                        <div class="row flex-grow">
                                            <div class="col-12 col-lg-4 col-lg-12 grid-margin stretch-card">
                                                <div class="card card-rounded">
                                                    <div class="card-body">
                                                        <div class="d-sm-flex justify-content-between align-items-start">
                                                            <div>
                                                                <h4 class="card-title card-title-dash">Performance Line Chart</h4>
                                                                <h5 class="card-subtitle card-subtitle-dash">Lorem Ipsum is simply dummy text of the printing</h5>
                                                            </div>
                                                            <div id="performance-line-legend"></div>
                                                        </div>
                                                        <div class="chartjs-wrapper mt-5">
                                                            <canvas id="performaneLine"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4 grid-margin stretch-card">
                                        <div class="card card-rounded table-darkBGImg">
                                            <div class="card-body">
                                                <div class="col-sm-8">
                                                    <h3 class="text-white upgrade-info mb-0">
                                                        Click Here <br><span class="fw-bold">To Create</span><br> New Tickets!
                                                    </h3>
                                                    <a href="./index.php" class="btn btn-info upgrade-btn">Create Ticket!</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 d-flex flex-column">
                                        <div class="row flex-grow">
                                            <div class="col-12 grid-margin stretch-card">
                                                <div class="card card-rounded">
                                                    <div class="card-body">
                                                        <div class="d-sm-flex align-items-center justify-content-between border-bottom">
                                                            <div class="row">
                                                                <div class="col-md-4">
                                                                    <ul class="nav nav-tabs" role="tablist">
                                                                        <li class="nav-item">
                                                                            <button class="nav-link ps-0" id="taday" onclick="fetch_data('today')">Today</button>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <button class="nav-link" id="weekly" onclick="fetch_data('weekly')">Weekly</button>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <button class="nav-link" id="monthly" onclick="fetch_data('monthly')">Monthly</button>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <button class="nav-link border-0" id="yearly" onclick="fetch_data('yearly')">Yearly</button>
                                                                        </li>
                                                                    </ul>
                                                                    <ul class="nav nav-tabs" role="tablist">
                                                                        <li class="nav-item">
                                                                            <button class="nav-link ps-0" id="Cash" onclick="fetch_data('Cash')">Cash</button>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <button class="nav-link" id="Card" onclick="fetch_data('Card')">Card</button>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <button class="nav-link" id="Phonepe" onclick="fetch_data('Phonepe')">Phonepe</button>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <button class="nav-link border-0" id="NEFT/RTGS" onclick="fetch_data('NEFT/RTGS')">NEFT/RTGS</button>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <button class="nav-link" id="Shoutlo" onclick="fetch_data('Shoutlo')">Shoutlo</button>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <button class="nav-link border-0" id="Razorpay" onclick="fetch_data('Razorpay')">Razorpay</button>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <div class="col-md-3 d-flex justify-content-end d-flex justify-content-end">
                                                                    <select name="ticket_type" id="ticket_type" class="form-control form-control-lg">
                                                                        <option value="ALL" selected>ALL</option>
                                                                        <option value="AMUSEMENT PARK">AMUSEMENT PARK</option>
                                                                        <option value="WUNDER WATER">WUNDER WATER</option>
                                                                        <option value="COMBO – AMUSEMENT PARK + WATER PARK">COMBO – AMUSEMENT PARK + WATER PARK</option>
                                                                        <option value="Yearly Membership – Couple">Yearly Membership – Couple</option>
                                                                        <option value="Yearly Membership – Family">Yearly Membership – Family</option>
                                                                    </select>
                                                                </div>
                                                                <div class="col-md-3 row d-flex justify-content-end">
                                                                    <input type="date" class="form-control d-flex justify-content-end" id="date_from" name="from">
                                                                    <input type="date" class="form-control d-flex justify-content-end mb-2" max="<?= date('Y-m-d'); ?>" id="date_to" name="to">
                                                                </div>
                                                                <div class="btn-wrapper col-md-2">
                                                                    <button onclick="printReport()" class="btn btn-otline-dark"><i class="icon-printer"></i> Print</button>
                                                                    <button onclick="onSubmitButton()" class="btn btn-primary text-white me-0"> Submit</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="row" id="notification">
                                                                    <?php
                                                                    $fetch_data = mysqli_query($conn, "SELECT * FROM ticket");
                                                                    $count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket"));
                                                                    if ($count == 0) {
                                                                        echo '<div class="col-md-12 btn btn-danger text-white">
                                                                                    <h6 class="mt-2">No Record Found!</h6>
                                                                                    </div>
                                                                                    </div>';
                                                                    } else if ($fetch_data) {
                                                                        echo '
                                                                            <div class="table-responsive">
                                                                                <table class="table table-hover table-striped">
                                                                                    <thead>
                                                                                        <tr>
                                                                                            <th>Ticket Id</th>
                                                                                            <th>Name</th>
                                                                                            <th>Email</th>
                                                                                            <th>QTY</th>
                                                                                            <th>Type</th>
                                                                                            <th>CheckIn Date</th>
                                                                                            <th>Discount</th>
                                                                                            <th>Discount/ticket</th>
                                                                                            <th>Method</th>
                                                                                            <th>Ticket Status</th>
                                                                                            <th>Date</th>
                                                                                        </tr>
                                                                                    </thead>
                                                                                    <tbody>';
                                                                        while ($row = mysqli_fetch_array($fetch_data)) {
                                                                            $ticket_id = $row['id'];
                                                                            $ticket_username = $row['ticket_username'];
                                                                            $ticket_user_email = $row['ticket_user_email'];
                                                                            $ticket_quantity = $row['ticket_quantity'];
                                                                            $ticket_name = $row['ticket_name'];
                                                                            $ticket_check_in_date = $row['ticket_check_in_date'];
                                                                            $ticket_user_email = $row['ticket_user_email'];
                                                                            $discount = $row['discount'];
                                                                            $discount_pt = $row['discount_pt'];
                                                                            $payment_method = $row['payment_method'];
                                                                            $cancel_ticket = $row['cancel_ticket'];
                                                                            $created_at = $row['created_at'];
                                                                            echo '
                                                                                        <tr>

                                                                                            <td class="">' . $ticket_id . '</td>
                                                                                            <td class="">' . $ticket_username . '</td>
                                                                                            <td class="">' . $ticket_user_email . '</span></td>
                                                                                            <td class="">' . str_replace(",", "<br>", $ticket_quantity) . '</span></td>
                                                                                            <td class="">' . str_replace(",", "<br>", $ticket_name) . '</span></td>
                                                                                            <td class="">' . $ticket_check_in_date . '</span></td>
                                                                                            <td class="">' . $discount . '</span></td>
                                                                                            <td class="">' . $discount_pt . '</span></td>
                                                                                            <td class="">' . $payment_method . '</span></td>
                                                                                            <td class="">' . $cancel_ticket . '</span></td>
                                                                                            <td class="">' . $created_at . '</span></td>
                                                                                        </tr>';
                                                                        }
                                                                        echo '
                                                                                    </tbody>
                                                                                </table>';
                                                                    } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function formatDate(date) {
            var day = date.getDate();
            var month = date.getMonth() + 1; // Month is zero-based
            var year = date.getFullYear();

            // Pad single-digit day and month with leading zeros
            if (day < 10) {
                day = '0' + day;
            }
            if (month < 10) {
                month = '0' + month;
            }

            return day + '/' + month + '/' + year;
        }

        function fetch_data(str) {
            if (str == 'today') {
                var ticket_type = document.getElementById('ticket_type').value;

                var today = new Date();
                var year = today.getFullYear();
                var month = today.getMonth() + 1; // Months are zero-based, so add 1
                var day = today.getDate();
                var formattedDate = day.toString().padStart(2, '0') + '/' + month.toString().padStart(2, '0') + '/' + year;
                console.log(formattedDate);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/today.php?type=normal&&ticket_type=" + ticket_type + "&&today=" + formattedDate);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'weekly') {
                var ticket_type = document.getElementById('ticket_type').value;

                var today = new Date();
                var currentDay = today.getDay(); // Get the current day of the week (0 - Sunday, 1 - Monday, ..., 6 - Saturday)
                var startDate = new Date(today); // Create a new Date object with today's date
                var endDate = new Date(today); // Create a new Date object with today's date

                // Calculate the difference in days between the current day and Sunday (0 - Sunday, 1 - Monday, ..., 6 - Saturday)
                var daysUntilSunday = (currentDay + 7 - 0) % 7;

                // Set the start date to the previous Sunday
                startDate.setDate(today.getDate() - daysUntilSunday);

                // Set the end date to the following Sunday
                endDate.setDate(startDate.getDate() - 6);

                // Format the start and end dates as desired
                var formattedStartDate = formatDate(startDate); // Format: "YYYY-MM-DD"
                var formattedEndDate = formatDate(endDate); // Format: "YYYY-MM-DD"

                console.log(formattedStartDate + " - " + formattedEndDate);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&ticket_type=" + ticket_type + "&&date_from=" + formattedStartDate + "&&date_to=" + formattedEndDate);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'monthly') {
                var ticket_type = document.getElementById('ticket_type').value;

                var today = new Date();
                var year = today.getFullYear(); // Get the current year
                var month = today.getMonth(); // Get the current month (0 - January, 1 - February, ..., 11 - December)

                // Set the start date to the first day of the month
                var startDate = new Date(year, month, 1);

                // Set the end date to the last day of the month
                var endDate = new Date(year, month + 1, 0);

                // Format the start and end dates as desired
                var formattedStartDate = formatDate(startDate); // Format: "YYYY-MM-DD"
                var formattedEndDate = formatDate(endDate); // Format: "YYYY-MM-DD"

                console.log(formattedStartDate + " - " + formattedEndDate);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&ticket_type=" + ticket_type + "&&date_from=" + formattedStartDate + "&&date_to=" + formattedEndDate);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'yearly') {
                var ticket_type = document.getElementById('ticket_type').value;

                function getYearDates() {
                    var currentDate = new Date();
                    var year = currentDate.getFullYear();
                    var startDate = new Date(year, 0, 1); // January 1st
                    var endDate = new Date(year, 11, 31); // December 31st

                    return {
                        startDate: startDate,
                        endDate: endDate
                    };
                }
                // Example usage:
                var yearDates = getYearDates();
                var startYear = yearDates.startDate;
                var endYear = yearDates.endDate;
                var startYear = formatDate(startYear); // Format: "YYYY-MM-DD"
                var endYear = formatDate(endYear); // Format: "YYYY-MM-DD"
                console.log("year " + startYear + " - " + endYear);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&ticket_type=" + ticket_type + "&&date_from=" + startYear + "&&date_to=" + endYear);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'Cash') {
                var ticket_type = document.getElementById('ticket_type').value;

                function getYearDates() {
                    var currentDate = new Date();
                    var year = currentDate.getFullYear();
                    var startDate = new Date(year, 0, 1); // January 1st
                    var endDate = new Date(year, 11, 31); // December 31st

                    return {
                        startDate: startDate,
                        endDate: endDate
                    };
                }
                // Example usage:
                var yearDates = getYearDates();
                var startYear = yearDates.startDate;
                var endYear = yearDates.endDate;
                var startYear = formatDate(startYear); // Format: "YYYY-MM-DD"
                var endYear = formatDate(endYear); // Format: "YYYY-MM-DD"
                console.log("year " + startYear + " - " + endYear);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&payment_type=" + str + "&&ticket_type=" + ticket_type + "&&date_from=" + startYear + "&&date_to=" + endYear);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'Card') {
                var ticket_type = document.getElementById('ticket_type').value;

                function getYearDates() {
                    var currentDate = new Date();
                    var year = currentDate.getFullYear();
                    var startDate = new Date(year, 0, 1); // January 1st
                    var endDate = new Date(year, 11, 31); // December 31st

                    return {
                        startDate: startDate,
                        endDate: endDate
                    };
                }
                // Example usage:
                var yearDates = getYearDates();
                var startYear = yearDates.startDate;
                var endYear = yearDates.endDate;
                var startYear = formatDate(startYear); // Format: "YYYY-MM-DD"
                var endYear = formatDate(endYear); // Format: "YYYY-MM-DD"
                console.log("year " + startYear + " - " + endYear);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&payment_type=" + str + "&&ticket_type=" + ticket_type + "&&date_from=" + startYear + "&&date_to=" + endYear);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'Phonepe') {
                var ticket_type = document.getElementById('ticket_type').value;

                function getYearDates() {
                    var currentDate = new Date();
                    var year = currentDate.getFullYear();
                    var startDate = new Date(year, 0, 1); // January 1st
                    var endDate = new Date(year, 11, 31); // December 31st

                    return {
                        startDate: startDate,
                        endDate: endDate
                    };
                }
                // Example usage:
                var yearDates = getYearDates();
                var startYear = yearDates.startDate;
                var endYear = yearDates.endDate;
                var startYear = formatDate(startYear); // Format: "YYYY-MM-DD"
                var endYear = formatDate(endYear); // Format: "YYYY-MM-DD"
                console.log("year " + startYear + " - " + endYear);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&payment_type=" + str + "&&ticket_type=" + ticket_type + "&&date_from=" + startYear + "&&date_to=" + endYear);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'NEFT/RTGS') {
                var ticket_type = document.getElementById('ticket_type').value;

                function getYearDates() {
                    var currentDate = new Date();
                    var year = currentDate.getFullYear();
                    var startDate = new Date(year, 0, 1); // January 1st
                    var endDate = new Date(year, 11, 31); // December 31st

                    return {
                        startDate: startDate,
                        endDate: endDate
                    };
                }
                // Example usage:
                var yearDates = getYearDates();
                var startYear = yearDates.startDate;
                var endYear = yearDates.endDate;
                var startYear = formatDate(startYear); // Format: "YYYY-MM-DD"
                var endYear = formatDate(endYear); // Format: "YYYY-MM-DD"
                console.log("year " + startYear + " - " + endYear);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&payment_type=" + str + "&&ticket_type=" + ticket_type + "&&date_from=" + startYear + "&&date_to=" + endYear);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'Shoutlo') {
                var ticket_type = document.getElementById('ticket_type').value;

                function getYearDates() {
                    var currentDate = new Date();
                    var year = currentDate.getFullYear();
                    var startDate = new Date(year, 0, 1); // January 1st
                    var endDate = new Date(year, 11, 31); // December 31st

                    return {
                        startDate: startDate,
                        endDate: endDate
                    };
                }
                // Example usage:
                var yearDates = getYearDates();
                var startYear = yearDates.startDate;
                var endYear = yearDates.endDate;
                var startYear = formatDate(startYear); // Format: "YYYY-MM-DD"
                var endYear = formatDate(endYear); // Format: "YYYY-MM-DD"
                console.log("year " + startYear + " - " + endYear);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&payment_type=" + str + "&&ticket_type=" + ticket_type + "&&date_from=" + startYear + "&&date_to=" + endYear);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            } else if (str == 'Razorpay') {
                var ticket_type = document.getElementById('ticket_type').value;

                function getYearDates() {
                    var currentDate = new Date();
                    var year = currentDate.getFullYear();
                    var startDate = new Date(year, 0, 1); // January 1st
                    var endDate = new Date(year, 11, 31); // December 31st

                    return {
                        startDate: startDate,
                        endDate: endDate
                    };
                }
                // Example usage:
                var yearDates = getYearDates();
                var startYear = yearDates.startDate;
                var endYear = yearDates.endDate;
                var startYear = formatDate(startYear); // Format: "YYYY-MM-DD"
                var endYear = formatDate(endYear); // Format: "YYYY-MM-DD"
                console.log("year " + startYear + " - " + endYear);
                // Create a new XMLHttpRequest object
                const xhr = new XMLHttpRequest();

                // Define the AJAX request
                xhr.open("GET", "./helpers/week_year.php?type=normal&&payment_type=" + str + "&&ticket_type=" + ticket_type + "&&date_from=" + startYear + "&&date_to=" + endYear);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        const response = xhr.responseText;
                        document.getElementById('notification').innerHTML = response;
                        console.log(response);
                        // Do something with the response data
                    }
                }
                // Send the AJAX request with the data
                xhr.send();
            }

        }



        function onSubmitButton() {
            var ticket_type2 = document.getElementById('ticket_type').value;
            var date_from2 = new Date(document.getElementById('date_from').value);
            var date_to2 = new Date(document.getElementById('date_to').value);



            date_from2 = formatDate(date_from2);
            date_to2 = formatDate(date_to2);
            console.log(date_from2 + " - " + date_to2);

            // Create a new XMLHttpRequest object
            const xhr = new XMLHttpRequest();

            // Define the AJAX request
            xhr.open("GET", "./helpers/reports.php?type=normal&&ticket_type=" + ticket_type2 + "&&date_from=" + date_from2 + "&&date_to=" + date_to2);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                    const response = xhr.responseText;
                    document.getElementById('notification').innerHTML = response;
                    console.log(response);
                    // Do something with the response data
                }
            }
            // Send the AJAX request with the data
            xhr.send();
        }



        const ctx = document.getElementById('performaneLine');
        const data = {
            labels: [
                'AMUSEMENT PARK',
                'WUNDER WATER',
                'COMBO – AP + WP',
                'Yearly – Couple',
                'Yearly – Family',
            ],
            datasets: [{
                type: 'line',
                label: 'Ticket Sold',
                data: [<?php echo mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%AMUSEMENT%'")); ?>, <?php echo mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%WUNDER WATER%'")) ?>, <?php echo mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%COMBO%'")) ?>, <?php echo mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%Couple%'")) ?>, <?php echo mysqli_num_rows(mysqli_query($conn, "SELECT * FROM ticket WHERE ticket_name LIKE '%Family%'")) ?>],
                fill: true,
            }]
        };
        var salesTopOptions = {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    gridLines: {
                        display: true,
                        drawBorder: false,
                        color: "#F0F0F0",
                        zeroLineColor: '#F0F0F0',
                    },
                    ticks: {
                        beginAtZero: false,
                        autoSkip: true,
                        maxTicksLimit: 4,
                        fontSize: 10,
                        color: "#6B778C"
                    }
                }],
                xAxes: [{
                    gridLines: {
                        display: false,
                        drawBorder: false,
                    },
                    ticks: {
                        beginAtZero: false,
                        autoSkip: true,
                        maxTicksLimit: 7,
                        fontSize: 10,
                        color: "#6B778C"
                    }
                }],
            },
            legend: false,
            legendCallback: function(chart) {
                var text = [];
                text.push('<div class="chartjs-legend"><ul>');
                for (var i = 0; i < chart.data.datasets.length; i++) {
                    console.log(chart.data.datasets[i]); // see what's inside the obj.
                    text.push('<li>');
                    text.push('<span style="background-color:' + chart.data.datasets[i].borderColor + '">' + '</span>');
                    text.push(chart.data.datasets[i].label);
                    text.push('</li>');
                }
                text.push('</ul></div>');
                return text.join("");
            },

            elements: {
                line: {
                    tension: 0.4,
                }
            },
            tooltips: {
                backgroundColor: 'rgba(31, 59, 179, 1)',
            }
        }
        const mixedChart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: salesTopOptions,
            tension: 1,
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            borderWidth: 1,
            tension: 0.4, // Set tension to create curved lines
            fill: true // Fill area under the line
        });

        function printReport() {
            var report = document.getElementById('notification').innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = report;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload()
        }
    </script>
    <?php include('./components/footer.php') ?>
    <?php include('./components/scripts.php') ?>